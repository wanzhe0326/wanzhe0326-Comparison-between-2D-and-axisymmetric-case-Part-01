i=1;

switch(i)
    
    case 1
 x=-199:1:200;
% plot(x,Result3(1,1:400),'r','LineWidth',1.5);
plot(x,result444(1,1:400),'r','LineWidth',1.5);
hold on
plot(x,result555(1,1:400),'k','LineWidth',1.5);
plot(x,result666(1,1:400),'b','LineWidth',1.5);
plot(x,result777(1,1:400),'g','LineWidth',1.5);
xlabel('Distance (in)') 
ylabel('Pore pressure (psi)')
legend({'100 in. away','200 in. away','300 in. away','400 in. away'})
% ylabel('Vertical stress (psi)') 
% legend({'Moving Point','Moving Load'})


    case 2
x=-199:1:200;
plot(x,Result6(1,1:400),'r','LineWidth',1.5);
hold on
plot(x,result666,'k','LineWidth',1.5);
xlabel('Distance (in)') 
ylabel('Pore pressure (psi)') 
legend({'Moving Point','Moving Load'})


    case 3
 x=-199:1:200;
A =abs( result333(1,1:400)- Result3(1,1:400));
plot(x,A,'r','LineWidth',1.5);
xlabel('Distance (in)') 
ylabel('Difference vertical stress (psi)') 
 legend({'abs(MP - ML)'})


    case 4
 x=-199:1:200;
B=abs(result666-Result6(1,1:400));
plot(x,B,'k','LineWidth',1.5);
xlabel('Distance (in)') 
ylabel('Difference pore pressure (psi)') 
 legend({'abs(MP - ML)'})

end


ax = gca;
ax.FontSize = 15;

