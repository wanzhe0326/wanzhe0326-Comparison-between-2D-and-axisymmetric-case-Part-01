function [ Coeff_21,Coeff_22,Coeff_23,Coeff_24,Coeff_25,Coeff_26,Coeff_27,Coeff_28,Coeff_41,Coeff_42,Coeff_43,Coeff_44,Coeff_45,Coeff_46,Coeff_47,Coeff_48,Coeff_49,Coeff_410,Coeff_411,Coeff_412,Coeff_413,Coeff_414]=InputPoroElastic(M,b,alpha,m,poisson,rho,rhof,E,dy,dt,dx)
%----------------------------------------------------------------------------------------------------------------------------------------------------------------


lambda = E*poisson/(1+poisson)/(1-2*poisson);
miu=E/2/(1+poisson);

        Coeff_2 = dt * 1/( rho*m - rhof^2 );
        Coeff_21 = Coeff_2 * m/dx;
        Coeff_22 = Coeff_2 * m/dy;
        Coeff_23 = Coeff_2 * rhof /dy;
        Coeff_24 = Coeff_2 * rhof *b;
        Coeff_25 = Coeff_2 * rho /dy;
        Coeff_26 = Coeff_2 * rho *b;
        Coeff_27 = Coeff_2 * rhof /dx;
        Coeff_28 = Coeff_2 * rho /dx;

        Coeff_41 =  dt * M /dx ;
        Coeff_42 =  dt * M /dy ;
        Coeff_43 = Coeff_41 * alpha  ;
        Coeff_44 = Coeff_42 * alpha  ;
        Coeff_45 = (lambda + alpha^2 *M + 2 * miu) * dt /dx  ;
        Coeff_46 = (lambda + alpha^2 *M + 2 * miu) * dt /dy  ;
        Coeff_47=( lambda + alpha^2 *M )*dt/dx;
        Coeff_48=( lambda + alpha^2 *M )*dt/dy;
        Coeff_49= miu *dt/dy;
        Coeff_410=miu *dt/dx;
        Coeff_411=rhof/m;
        Coeff_412=(dy/m)*b*rhof;
        Coeff_413=rhof/rho*dy/dx;
        Coeff_414=rhof/rho;

