%% ==================== Three Layer Poroelasticity ====================
%  By: Zhe Wan 08/25/2019
%  This is a three-layer model, where Layer1 is assumed to be elastic;
%  Layer2 is elastic/poroelastic; Layer3 is elastic. Top surface is assumed
%  to be no shear; bottom surface is assumed to be no shear; left and right
%  side are both assumed to be no shear.
%  ------------
format long
tic

%% ==================== Part 1: Input Parameters ====================
%-----------------------------------------------------------------------------------
Delay=901;        % Delay is the landing time, and it is bigger then 1
Distance=200;
INTERVAL=10E2;

t=0.4+(Delay-1)*INTERVAL*1E-06;
dt=1E-06;  
start=0/dt+1;
nt=t/dt+1;

dy1=1;
dy2=1;
dy3=1;

dx=1;
width=880;              % width of the model
c=1:30;
% depth=10;               % depth of the model
L1=3;                  %  Thickness of Top Layer 
L2=6;                  %  Thickness of Middle Layer
L3=80;                 % Thickness of Bottom Layer  
Lx=8;                   % Load Radius = LR ;
LP=-100;                % Load Pressure = LP;
                       % how many intervals per print out of the file
EffectiveStress=1;     % 1: open to calcualte effective stress; 0: close, pure elastic case no need to calculate effective stress
ChooseL1=2;    % choose 1 or 2; 1 represent poroelastic case and 2 represent the elastic case
ChooseL2=1;    % choose 1 or 2; 1 represent poroelastic case and 2 represent the elastic case
ChooseL3=2;    % choose 1 or 2; 1 represent poroelastic case and 2 represent the elastic case

FourthOrder=0;  % choose 1 or 0; 1 open fourth order, 0 close fourth order

boundary=40;
BABS=0.000045;

% 1; % permeable PE/PE %DONE
% 2; % Impermeable E/E %DONE 
% 3; % Impermeable E/PE %DONE
% 4; % Impermeable PE/E %DONE 
% 5; % Impermeable PE/PE %DONE

surface1=3;
surface2=4;

surface1fullybounded=1;            %1: open ; 0 close.
surface2fullybounded=1;            %1: open ; 0 close.

%1.1 Top Layer----------------------------------------------------------------------------

 L1poisson=0.30;
 L1rhos=2.1E-04;
 L1E=5E5;
 
%1.2 Middle Layer-----------------------------------------------------------------------------
%  L2poisson=0.3525;
%  L2rhos=0.000176;
%  L2E=38435;
 L2K=43511/1.0018428;
 L2G=14235/1.0018428;
 L2rhos=1.76E-04;
 L2E=9*L2K*L2G/(3*L2K+L2G);
 L2poisson=(3*L2K-2*L2G)/(2*(3*L2K+L2G));
 
switch(ChooseL2) 
           
    case 1   
         L2rhof=9.36E-05;
% %         L1rho=1.87E-04;
%         
         L2alpha=1;       
         L2Kf=478625;
        
%         L2rhof=0;
%         L2alpha=0;       
%         L2M=0;
%         L2rho=0.000176;
%         L2m=0.5;
        
        L2f=0.2;          %porosity
        L2m=1.66*L2rhof/L2f;       
        L2M=L2Kf/L2f;       
%         L2b=0.31;
        e0=0.2/(1-0.2);
        e1=L2f/(1-L2f);
        L2b=4.68*( e0^3*(1+e1)/( e1^3*(1+e0) ) );
        L2rho=L2f*L2rhof+(1-L2f)*L2rhos;
end

%1.3 Bottom Layer----------------------------------------------------------------------------------

 L3poisson=0.45;
 L3rhos=1.43E-04;
 L3E=8000;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% ==================== Part 2: Mesh  ====================

% 2.1 Size of mesh  grids
%------------

nx=fix(width/dx);   % space r step

ny=fix( L1/dy1 + L2/dy2 + L3/dy3 + 1);   % space z step

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[Surface1L1V12,Surface1L2V12,Surface1L1V22,Surface1L2V22,UpperPsurface1,LowerPsurface1,Surface1L2Shear]=BoundaryCondition(surface1,surface1fullybounded);
[Surface2L2V12,Surface2L3V12,Surface2L2V22,Surface2L3V22,UpperPsurface2,LowerPsurface2,Surface2L3Shear]=BoundaryCondition(surface2,surface2fullybounded);

%Layer 1

L1j1upV12=1;
L1j1downV12=L1/dy1+Surface1L1V12;  
L1j2upShear=3;
L1j2downShear=(L1/dy1+1);
L1j1upNormal=2;
L1j1downNormal=(L1/dy1+1);

switch(ChooseL1) 
            
    case 1   
        
        L1j2upV22 = 1 ;
        L1j2downV22 = L1/dy1 + Surface1L1V22 ; 
        
        L1j3upV1121 = 2;
        L1j3downV1121 = L1/dy1 + 1;     
        Ptopsurface=1;      % No need to backcalculate P    
        
    case 2 
             
        L1j2upV11=2;
        L1j2downV11=L1/dy1+1;

end

%Layer 2

      L2j1upV12 = L1/dy1 + 2  + Surface1L2V12;
      L2j1downV12 = L1/dy1 + L2/dy2 + Surface2L2V12;
      L2j2upShear = L1/dy1 + 2 + Surface1L2Shear;
      L2j2downShear = L1/dy1 + L2/dy2 + 1;      
      L2j1upNormal = L1/dy1 + 2 ;
      L2j1downNormal = L1/dy1 + L2/dy2 + 1 ;        
      
switch(ChooseL2) 
       
    case 1    
        
        L2j2upV22 = L1/dy1 + 2 + Surface1L2V22 ;
        L2j2downV22 = L1/dy1 + L2/dy2 + Surface2L2V22 ;       
        L2j3upV1121 = L1/dy1 + 2;
        L2j3downV1121 = L1/dy1 + L2/dy2 + 1;   
               
    case 2                       

        L2j2upV11 = L1/dy1 + 2;
        L2j2downV11 = L1/dy1 + L2/dy2 + 1 ;
               
end

%Layer 3

        L3j1upV12 = L1/dy1 + L2/dy2 + 2 + Surface2L3V12;
        L3j1downV12=(ny-1);
        L3j2upShear = L1/dy1 + L2/dy2 + 2 + Surface2L3Shear;
        L3j2downShear=ny;
        L3j1upNormal = L1/dy1 + L2/dy2 + 2;
        L3j1downNormal= ny;          % bottom impermeable p backcalculated!!
       
        
switch(ChooseL3) 
            
    case 1   
        
        L3j2upV22 = L1/dy1 + L2/dy2 + 2 + Surface2L3V22 ;
        L3j2downV22 = L1/dy1 + L2/dy2 + L3/dy3 ;   %bottom special
        
        L3j3upV1121 = L1/dy1 + L2/dy2 + 2 ;
        L3j3downV1121 = ny;         
        Pbottomsurface=0;   % Do need to backcalculate P
        
    case 2 
         
        L3j2upV11 = L1/dy1 + L2/dy2 + 2;
        L3j2downV11=ny;

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 2.2 Size of variables matrices
%------------
if start==1
%------------------------------------------------------------------------------------    
NCsigma_xx=zeros(nx+1,ny);       % total stress in r direction  when y=ny+1 it is meaningless do not care 

NCsigma_yy=zeros(nx+1,ny);       % total stress in z direction

NCsigma_xy=zeros(nx+1,ny+1);   % shear stress 

NCp=zeros(nx+1,ny);              % pore pressure; when bottom is impermeable, p needs to be backcalculated thus nz+1
     
%------------------------------------------------------------------------------------

NCv11=zeros(nx+1,ny);          % dux/dt, speed of soil component in x direction
 
NCv12=zeros(nx,ny);            % duy/dt, relativly speed of soil component in y direction    

NCv21=zeros(nx+1,ny);          % dwx/dt, relativly speed of fluid component in x direction     

NCv22=zeros(nx,ny);            % dwy/dt, relativly speed of fluid component in y direction


%------------------------------------------------------------------------------------

% 2.3 Size of displacement matrices
%------------
        
NCu11=zeros(nx+1,ny); 

NCu21=zeros(nx+1,ny);  
        
NCu12=zeros(nx,ny);  

NCu22=zeros(nx,ny);  
   
else    
    start=start+1;   
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ==================== Part 3: Calculated Paramters in Equations  ====================

%------------------------------------------------------------------------------------
 
switch(ChooseL1)
    
    case 1
        
 [ L1Coeff_21,L1Coeff_22,L1Coeff_23,L1Coeff_24,L1Coeff_25,L1Coeff_26,L1Coeff_27,L1Coeff_28,L1Coeff_41,L1Coeff_42,L1Coeff_43,L1Coeff_44,L1Coeff_45,L1Coeff_46,L1Coeff_47,L1Coeff_48,L1Coeff_49,L1Coeff_410,L1Coeff_411,L1Coeff_412,L1Coeff_413,L1Coeff_414]=InputPoroElastic(L1M,L1b,L1alpha,L1m,L1poisson,L1rho,L1rhof,L1E,dy1,dt,dx);

        
    case 2
        
 [ L1Coeff_11,L1Coeff_12,L1Coeff_32,L1Coeff_34,L1Coeff_36,L1Coeff_38,L1Coeff_39,L1Coeff_310 ]=InputElastic(L1poisson,L1rhos,L1E,dy1,dt,dx);

end

%------------------------------------------------------------------------------------
switch(ChooseL2)
    
    case 1
        
 [ L2Coeff_21,L2Coeff_22,L2Coeff_23,L2Coeff_24,L2Coeff_25,L2Coeff_26,L2Coeff_27,L2Coeff_28,L2Coeff_41,L2Coeff_42,L2Coeff_43,L2Coeff_44,L2Coeff_45,L2Coeff_46,L2Coeff_47,L2Coeff_48,L2Coeff_49,L2Coeff_410,L2Coeff_411,L2Coeff_412,L2Coeff_413,L2Coeff_414]=InputPoroElastic(L2M,L2b,L2alpha,L2m,L2poisson,L2rho,L2rhof,L2E,dy2,dt,dx);
        
    case 2
        
 [ L2Coeff_11,L2Coeff_12,L2Coeff_32,L2Coeff_34,L2Coeff_36,L2Coeff_38,L2Coeff_39,L2Coeff_310 ]=InputElastic(L2poisson,L2rhos,L2E,dy2,dt,dx);        
 
end
%------------------------------------------------------------------------------------
switch(ChooseL3)
    
    case 1
        
 [ L3Coeff_21,L3Coeff_22,L3Coeff_23,L3Coeff_24,L3Coeff_25,L3Coeff_26,L3Coeff_27,L3Coeff_28,L3Coeff_41,L3Coeff_42,L3Coeff_43,L3Coeff_44,L3Coeff_45,L3Coeff_46,L3Coeff_47,L3Coeff_48,L3Coeff_49,L3Coeff_410,L3Coeff_411,L3Coeff_412,L3Coeff_413,L3Coeff_414]=InputPoroElastic(L3M,L3b,L3alpha,L3m,L3poisson,L3rho,L3rhof,L3E,dy3,dt,dx);
        
    case 2
        
 [ L3Coeff_11,L3Coeff_12,L3Coeff_32,L3Coeff_34,L3Coeff_36,L3Coeff_38,L3Coeff_39,L3Coeff_310 ]=InputElastic(L3poisson,L3rhos,L3E,dy3,dt,dx);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ==================== Part 4: MainPart_Velocites  ====================
% 4.1 force on top layer

%   i=1:1:(Lx/dx); 
%   
%        NCsigma_yy(i,1)=LP; 

starter=nx/2-(Lx/dx/2)-Distance/1;
a=1:1:Lx/dx; 
b=starter+a;
speed=INTERVAL+0.0001;
ender=starter+Lx/dx;

for tt=start:1:nt
%%----------------------------------------------------------------------------------------------------------------------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

       NCsigma_yy(:,1)=0;        
       k=fix(tt/speed);                                      
       d=fix((tt-INTERVAL*k)/1.0001)+1;
       
     
      if k <= Delay-1
         
       NCsigma_yy(b,1)=LP*tt/(Delay*INTERVAL);
 
      else     
       k=k-(Delay-1);
       NCsigma_yy(b+k-1,1)=LP*(1-d/INTERVAL);       
       NCsigma_yy(b+k,1)=NCsigma_yy(b+k-1,1)+ LP*(d/INTERVAL);       
       NCsigma_yy(ender+k,1) = LP*(d/INTERVAL);   
       
      end 

 
% 4.2 Upper elastic layer 

switch(ChooseL1)
    
    case 1
        
     switch(tt)
         
         case 1  
             
      [ NCv11,NCv12,NCv21,NCv22,L1av11new1,L1av12new1,L1av21new1,L1av22new1,L1av22new2,L1av12new2,L1av12new3,L1av22new3,L1av21new2,L1av11new2,L1av21new3,L1av11new3]=VelocityPoroElastic(L1j1upV12,L1j1downV12,L1j2upV22,L1j2downV22,L1j3upV1121,L1j3downV1121,nx,NCv11,NCv12,NCv21,NCv22,NCsigma_xy,NCsigma_xx,NCsigma_yy,NCp,L1Coeff_21,L1Coeff_22,L1Coeff_23,L1Coeff_24,L1Coeff_25,L1Coeff_26,L1Coeff_27,L1Coeff_28,FourthOrder,tt); % here is trciky, all accelarate does not need but must be left at the very end of input position of function, otherwise it can not be deleted.

         
         otherwise
             
      [ NCv11,NCv12,NCv21,NCv22,L1av11new1,L1av12new1,L1av21new1,L1av22new1,L1av22new2,L1av12new2,L1av12new3,L1av22new3,L1av21new2,L1av11new2,L1av21new3,L1av11new3]=VelocityPoroElastic(L1j1upV12,L1j1downV12,L1j2upV22,L1j2downV22,L1j3upV1121,L1j3downV1121,nx,NCv11,NCv12,NCv21,NCv22,NCsigma_xy,NCsigma_xx,NCsigma_yy,NCp,L1Coeff_21,L1Coeff_22,L1Coeff_23,L1Coeff_24,L1Coeff_25,L1Coeff_26,L1Coeff_27,L1Coeff_28,FourthOrder,tt,L1av11new1,L1av12new1,L1av21new1,L1av22new1,L1av12new2,L1av12new3,L1av22new2,L1av22new3,L1av21new2,L1av11new2,L1av21new3,L1av11new3);
  
  
     end
     
    case 2
        
 switch(tt)
     
         case 1  
             
     [ NCv11,NCv12,L1av11new1,L1av12new1,L1av12new2,L1av12new3,L1av11new2,L1av11new3]=VelocityElastic(L1j1upV12,L1j1downV12,L1j2upV11,L1j2downV11,nx,NCv11,NCv12,NCsigma_xx,NCsigma_yy,NCsigma_xy,L1Coeff_11,L1Coeff_12,FourthOrder,tt);

     
     otherwise       
         
     [ NCv11,NCv12,L1av11new1,L1av12new1,L1av12new2,L1av12new3,L1av11new2,L1av11new3]=VelocityElastic(L1j1upV12,L1j1downV12,L1j2upV11,L1j2downV11,nx,NCv11,NCv12,NCsigma_xx,NCsigma_yy,NCsigma_xy,L1Coeff_11,L1Coeff_12,FourthOrder,tt,L1av11new1,L1av12new1,L1av12new2,L1av12new3,L1av11new2,L1av11new3);
               
 end   
 
end

%----------------------------------------------------------------------------------------------------------------------------------------------------------------
% 4.3 Middle poroelastic layer

switch(ChooseL2)
    
    case 1
        
switch(tt) 
    
         case 1  
             
            [ NCv11,NCv12,NCv21,NCv22,L2av11new1,L2av12new1,L2av21new1,L2av22new1,L2av22new2,L2av12new2,L2av12new3,L2av22new3,L2av21new2,L2av11new2,L2av21new3,L2av11new3]=VelocityPoroElastic(L2j1upV12,L2j1downV12,L2j2upV22,L2j2downV22,L2j3upV1121,L2j3downV1121,nx,NCv11,NCv12,NCv21,NCv22,NCsigma_xy,NCsigma_xx,NCsigma_yy,NCp,L2Coeff_21,L2Coeff_22,L2Coeff_23,L2Coeff_24,L2Coeff_25,L2Coeff_26,L2Coeff_27,L2Coeff_28,FourthOrder,tt);
  
    otherwise
           
            [ NCv11,NCv12,NCv21,NCv22,L2av11new1,L2av12new1,L2av21new1,L2av22new1,L2av22new2,L2av12new2,L2av12new3,L2av22new3,L2av21new2,L2av11new2,L2av21new3,L2av11new3]=VelocityPoroElastic(L2j1upV12,L2j1downV12,L2j2upV22,L2j2downV22,L2j3upV1121,L2j3downV1121,nx,NCv11,NCv12,NCv21,NCv22,NCsigma_xy,NCsigma_xx,NCsigma_yy,NCp,L2Coeff_21,L2Coeff_22,L2Coeff_23,L2Coeff_24,L2Coeff_25,L2Coeff_26,L2Coeff_27,L2Coeff_28,FourthOrder,tt,L2av11new1,L2av12new1,L2av21new1,L2av22new1,L2av12new2,L2av12new3,L2av22new2,L2av22new3,L2av21new2,L2av11new2,L2av21new3,L2av11new3);

end
    case 2
        
switch(tt) 
    
         case 1 
             
              [ NCv11,NCv12,L2av11new1,L2av12new1,L2av12new2,L2av12new3,L2av11new2,L2av11new3]=VelocityElastic(L2j1upV12,L2j1downV12,L2j2upV11,L2j2downV11,nx,NCv11,NCv12,NCsigma_xx,NCsigma_yy,NCsigma_xy,L2Coeff_11,L2Coeff_12,FourthOrder,tt);

    otherwise
        
             [ NCv11,NCv12,L2av11new1,L2av12new1,L2av12new2,L2av12new3,L2av11new2,L2av11new3]=VelocityElastic(L2j1upV12,L2j1downV12,L2j2upV11,L2j2downV11,nx,NCv11,NCv12,NCsigma_xx,NCsigma_yy,NCsigma_xy,L2Coeff_11,L2Coeff_12,FourthOrder,tt,L2av11new1,L2av12new1,L2av12new2,L2av12new3,L2av11new2,L2av11new3);

end

end
%----------------------------------------------------------------------------------------------------------------------------------------------------------------
% 4.4 Lower elastic layer    
%----------------------------------------------------------------------------------------------------------------------------------------------------------------

switch(ChooseL3)
    
    case 1
        
 switch(tt) 
     
         case 1     
             
        [ NCv11,NCv12,NCv21,NCv22,L3av11new1,L3av12new1,L3av21new1,L3av22new1,L3av22new2,L3av12new2,L3av12new3,L3av22new3,L3av21new2,L3av11new2,L3av21new3,L3av11new3]=VelocityPoroElastic(L3j1upV12,L3j1downV12,L3j2upV22,L3j2downV22,L3j3upV1121,L3j3downV1121,nx,NCv11,NCv12,NCv21,NCv22,NCsigma_xy,NCsigma_xx,NCsigma_yy,NCp,L3Coeff_21,L3Coeff_22,L3Coeff_23,L3Coeff_24,L3Coeff_25,L3Coeff_26,L3Coeff_27,L3Coeff_28,FourthOrder,tt);

     otherwise
         
       [ NCv11,NCv12,NCv21,NCv22,L3av11new1,L3av12new1,L3av21new1,L3av22new1,L3av22new2,L3av12new2,L3av12new3,L3av22new3,L3av21new2,L3av11new2,L3av21new3,L3av11new3]=VelocityPoroElastic(L3j1upV12,L3j1downV12,L3j2upV22,L3j2downV22,L3j3upV1121,L3j3downV1121,nx,NCv11,NCv12,NCv21,NCv22,NCsigma_xy,NCsigma_xx,NCsigma_yy,NCp,L3Coeff_21,L3Coeff_22,L3Coeff_23,L3Coeff_24,L3Coeff_25,L3Coeff_26,L3Coeff_27,L3Coeff_28,FourthOrder,tt,L3av11new1,L3av12new1,L3av21new1,L3av22new1,L3av12new2,L3av12new3,L3av22new2,L3av22new3,L3av21new2,L3av11new2,L3av21new3,L3av11new3);

 end  
 
    case 2  
        
 switch(tt) 
     
         case 1
             
         [ NCv11,NCv12,L3av11new1,L3av12new1,L3av12new2,L3av12new3,L3av11new2,L3av11new3]=VelocityElastic(L3j1upV12,L3j1downV12,L3j2upV11,L3j2downV11,nx,NCv11,NCv12,NCsigma_xx,NCsigma_yy,NCsigma_xy,L3Coeff_11,L3Coeff_12,FourthOrder,tt);

     otherwise
         
        [ NCv11,NCv12,L3av11new1,L3av12new1,L3av12new2,L3av12new3,L3av11new2,L3av11new3]=VelocityElastic(L3j1upV12,L3j1downV12,L3j2upV11,L3j2downV11,nx,NCv11,NCv12,NCsigma_xx,NCsigma_yy,NCsigma_xy,L3Coeff_11,L3Coeff_12,FourthOrder,tt,L3av11new1,L3av12new1,L3av12new2,L3av12new3,L3av11new2,L3av11new3);

end
 
end

[ NCv11,NCv12,NCv21,NCv22]=AbsorbingBoundary01(boundary,BABS,nx,ny,NCv11,NCv12,NCv21,NCv22);


%%         
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ==================== Part 5: MainPart_Stresses  ====================
           
%%
%----------------------------------------------------------------------------------------------------------------------------------------------------------------
% 5.1 Upper elastic layer
%----------------------------------------------------------------------------------------------------------------------------------------------------------------
switch(ChooseL1)
    
        case 1
        
     switch(tt)
         
         case 1
         
        [ NCsigma_xx,NCsigma_yy,NCsigma_xy,NCp,L1aNCsigma_xxnew1,L1aNCsigma_xxnew2,L1aNCsigma_yynew1,L1aNCsigma_yynew2,L1aNCpnew1,L1aNCpnew2,L1aNCsigma_xynew1,L1aNCsigma_xxnew3,L1aNCsigma_yynew3,L1aNCpnew3,L1aNCsigma_xynew2,L1aNCsigma_xynew3]=ForcePoroElastic(L1j1upNormal,L1j1downNormal,L1j2upShear,L1j2downShear,nx,NCsigma_xx,NCsigma_yy,NCsigma_xy,NCp,L1Coeff_41,L1Coeff_42,L1Coeff_45,L1Coeff_46,L1Coeff_47,L1Coeff_48,L1Coeff_49,L1Coeff_410,L1Coeff_413,L1Coeff_414,L1Coeff_43,L1Coeff_44,NCv11,NCv12,NCv21,NCv22,Ptopsurface,LowerPsurface1,FourthOrder,tt);
             
        
         otherwise
             
        [ NCsigma_xx,NCsigma_yy,NCsigma_xy,NCp,L1aNCsigma_xxnew1,L1aNCsigma_xxnew2,L1aNCsigma_yynew1,L1aNCsigma_yynew2,L1aNCpnew1,L1aNCpnew2,L1aNCsigma_xynew1,L1aNCsigma_xxnew3,L1aNCsigma_yynew3,L1aNCpnew3,L1aNCsigma_xynew2,L1aNCsigma_xynew3]=ForcePoroElastic(L1j1upNormal,L1j1downNormal,L1j2upShear,L1j2downShear,nx,NCsigma_xx,NCsigma_yy,NCsigma_xy,NCp,L1Coeff_41,L1Coeff_42,L1Coeff_45,L1Coeff_46,L1Coeff_47,L1Coeff_48,L1Coeff_49,L1Coeff_410,L1Coeff_413,L1Coeff_414,L1Coeff_43,L1Coeff_44,NCv11,NCv12,NCv21,NCv22,Ptopsurface,LowerPsurface1,FourthOrder,tt,L1aNCsigma_xxnew1,L1aNCsigma_yynew1,L1aNCpnew1,L1aNCsigma_xynew1,L1aNCsigma_xxnew2,L1aNCsigma_xxnew3,L1aNCsigma_yynew2,L1aNCsigma_yynew3,L1aNCpnew2,L1aNCpnew3,L1aNCsigma_xynew2,L1aNCsigma_xynew3);
        
     end
    
    case 2
        
  switch(tt)
      
         case 1
             
        [ NCsigma_xx,NCsigma_yy,NCsigma_xy,L1aNCsigma_xxnew1,L1aNCsigma_xxnew2,L1aNCsigma_yynew1,L1aNCsigma_yynew2,L1aNCsigma_xynew1,L1aNCsigma_xxnew3,L1aNCsigma_yynew3,L1aNCsigma_xynew2,L1aNCsigma_xynew3]=ForceElastic(L1j1upNormal,L1j1downNormal,L1j2upShear,L1j2downShear,nx,NCsigma_xx,NCsigma_yy,NCsigma_xy,L1Coeff_32,L1Coeff_34,L1Coeff_36,L1Coeff_38,L1Coeff_39,L1Coeff_310,NCv11,NCv12,FourthOrder,tt);
                                                                     
      otherwise

        [ NCsigma_xx,NCsigma_yy,NCsigma_xy,L1aNCsigma_xxnew1,L1aNCsigma_xxnew2,L1aNCsigma_yynew1,L1aNCsigma_yynew2,L1aNCsigma_xynew1,L1aNCsigma_xxnew3,L1aNCsigma_yynew3,L1aNCsigma_xynew2,L1aNCsigma_xynew3]=ForceElastic(L1j1upNormal,L1j1downNormal,L1j2upShear,L1j2downShear,nx,NCsigma_xx,NCsigma_yy,NCsigma_xy,L1Coeff_32,L1Coeff_34,L1Coeff_36,L1Coeff_38,L1Coeff_39,L1Coeff_310,NCv11,NCv12,FourthOrder,tt,L1aNCsigma_xxnew1,L1aNCsigma_xxnew2,L1aNCsigma_yynew1,L1aNCsigma_yynew2,L1aNCsigma_xynew1,L1aNCsigma_xxnew3,L1aNCsigma_yynew3,L1aNCsigma_xynew2,L1aNCsigma_xynew3);
        

  end
  
end 
%----------------------------------------------------------------------------------------------------------------------------------------------------------------
% 5.2 Middle Poroelastic Layer
%%
switch(ChooseL2)
    
    case 1
        
     switch(tt)
         
         case 1
             
        [ NCsigma_xx,NCsigma_yy,NCsigma_xy,NCp,L2aNCsigma_xxnew1,L2aNCsigma_xxnew2,L2aNCsigma_yynew1,L2aNCsigma_yynew2,L2aNCpnew1,L2aNCpnew2,L2aNCsigma_xynew1,L2aNCsigma_xxnew3,L2aNCsigma_yynew3,L2aNCpnew3,L2aNCsigma_xynew2,L2aNCsigma_xynew3]=ForcePoroElastic(L2j1upNormal,L2j1downNormal,L2j2upShear,L2j2downShear,nx,NCsigma_xx,NCsigma_yy,NCsigma_xy,NCp,L2Coeff_41,L2Coeff_42,L2Coeff_45,L2Coeff_46,L2Coeff_47,L2Coeff_48,L2Coeff_49,L2Coeff_410,L2Coeff_413,L2Coeff_414,L2Coeff_43,L2Coeff_44,NCv11,NCv12,NCv21,NCv22,UpperPsurface1,LowerPsurface2,FourthOrder,tt);
             
       
         otherwise
             
        [ NCsigma_xx,NCsigma_yy,NCsigma_xy,NCp,L2aNCsigma_xxnew1,L2aNCsigma_xxnew2,L2aNCsigma_yynew1,L2aNCsigma_yynew2,L2aNCpnew1,L2aNCpnew2,L2aNCsigma_xynew1,L2aNCsigma_xxnew3,L2aNCsigma_yynew3,L2aNCpnew3,L2aNCsigma_xynew2,L2aNCsigma_xynew3]=ForcePoroElastic(L2j1upNormal,L2j1downNormal,L2j2upShear,L2j2downShear,nx,NCsigma_xx,NCsigma_yy,NCsigma_xy,NCp,L2Coeff_41,L2Coeff_42,L2Coeff_45,L2Coeff_46,L2Coeff_47,L2Coeff_48,L2Coeff_49,L2Coeff_410,L2Coeff_413,L2Coeff_414,L2Coeff_43,L2Coeff_44,NCv11,NCv12,NCv21,NCv22,UpperPsurface1,LowerPsurface2,FourthOrder,tt,L2aNCsigma_xxnew1,L2aNCsigma_yynew1,L2aNCpnew1,L2aNCsigma_xynew1,L2aNCsigma_xxnew2,L2aNCsigma_xxnew3,L2aNCsigma_yynew2,L2aNCsigma_yynew3,L2aNCpnew2,L2aNCpnew3,L2aNCsigma_xynew2,L2aNCsigma_xynew3);
        
     end
     
    case 2
        
        switch(tt)
            
         case 1
             
        [ NCsigma_xx,NCsigma_yy,NCsigma_xy,L2aNCsigma_xxnew1,L2aNCsigma_xxnew2,L2aNCsigma_yynew1,L2aNCsigma_yynew2,L2aNCsigma_xynew1,L2aNCsigma_xxnew3,L2aNCsigma_yynew3,L2aNCsigma_xynew2,L2aNCsigma_xynew3]=ForceElastic(L2j1upNormal,L2j1downNormal,L2j2upShear,L2j2downShear,nx,NCsigma_xx,NCsigma_yy,NCsigma_xy,L2Coeff_32,L2Coeff_34,L2Coeff_36,L2Coeff_38,L2Coeff_39,L2Coeff_310,NCv11,NCv12,FourthOrder,tt);
           
            otherwise
                
        [ NCsigma_xx,NCsigma_yy,NCsigma_xy,L2aNCsigma_xxnew1,L2aNCsigma_xxnew2,L2aNCsigma_yynew1,L2aNCsigma_yynew2,L2aNCsigma_xynew1,L2aNCsigma_xxnew3,L2aNCsigma_yynew3,L2aNCsigma_xynew2,L2aNCsigma_xynew3]=ForceElastic(L2j1upNormal,L2j1downNormal,L2j2upShear,L2j2downShear,nx,NCsigma_xx,NCsigma_yy,NCsigma_xy,L2Coeff_32,L2Coeff_34,L2Coeff_36,L2Coeff_38,L2Coeff_39,L2Coeff_310,NCv11,NCv12,FourthOrder,tt,L2aNCsigma_xxnew1,L2aNCsigma_xxnew2,L2aNCsigma_yynew1,L2aNCsigma_yynew2,L2aNCsigma_xynew1,L2aNCsigma_xxnew3,L2aNCsigma_yynew3,L2aNCsigma_xynew2,L2aNCsigma_xynew3);

        end
end  
%%
%----------------------------------------------------------------------------------------------------------------------------------------------------------------
% 5.3 Lower elastic layer
%----------------------------------------------------------------------------------------------------------------------------------------------------------------
switch(ChooseL3)
    
    case 1
        
       switch(tt)
           
        case 1
            
                [ NCsigma_xx,NCsigma_yy,NCsigma_xy,NCp,L3aNCsigma_xxnew1,L3aNCsigma_xxnew2,L3aNCsigma_yynew1,L3aNCsigma_yynew2,L3aNCpnew1,L3aNCpnew2,L3aNCsigma_xynew1,L3aNCsigma_xxnew3,L3aNCsigma_yynew3,L3aNCpnew3,L3aNCsigma_xynew2,L3aNCsigma_xynew3]=ForcePoroElastic(L3j1upNormal,L3j1downNormal,L3j2upShear,L3j2downShear,nx,NCsigma_xx,NCsigma_yy,NCsigma_xy,NCp,L3Coeff_41,L3Coeff_42,L3Coeff_45,L3Coeff_46,L3Coeff_47,L3Coeff_48,L3Coeff_49,L3Coeff_410,L3Coeff_413,L3Coeff_414,L3Coeff_43,L3Coeff_44,NCv11,NCv12,NCv21,NCv22,UpperPsurface2,Pbottomsurface,FourthOrder,tt);
              
           otherwise
               
               [ NCsigma_xx,NCsigma_yy,NCsigma_xy,NCp,L3aNCsigma_xxnew1,L3aNCsigma_xxnew2,L3aNCsigma_yynew1,L3aNCsigma_yynew2,L3aNCpnew1,L3aNCpnew2,L3aNCsigma_xynew1,L3aNCsigma_xxnew3,L3aNCsigma_yynew3,L3aNCpnew3,L3aNCsigma_xynew2,L3aNCsigma_xynew3]=ForcePoroElastic(L3j1upNormal,L3j1downNormal,L3j2upShear,L3j2downShear,nx,NCsigma_xx,NCsigma_yy,NCsigma_xy,NCp,L3Coeff_41,L3Coeff_42,L3Coeff_45,L3Coeff_46,L3Coeff_47,L3Coeff_48,L3Coeff_49,L3Coeff_410,L3Coeff_413,L3Coeff_414,L3Coeff_43,L3Coeff_44,NCv11,NCv12,NCv21,NCv22,UpperPsurface2,Pbottomsurface,FourthOrder,tt,L3aNCsigma_xxnew1,L3aNCsigma_yynew1,L3aNCpnew1,L3aNCsigma_xynew1,L3aNCsigma_xxnew2,L3aNCsigma_xxnew3,L3aNCsigma_yynew2,L3aNCsigma_yynew3,L3aNCpnew2,L3aNCpnew3,L3aNCsigma_xynew2,L3aNCsigma_xynew3);
              
       end
                
    case 2
        
  switch(tt)
      
         case 1
             
          [ NCsigma_xx,NCsigma_yy,NCsigma_xy,L3aNCsigma_xxnew1,L3aNCsigma_xxnew2,L3aNCsigma_yynew1,L3aNCsigma_yynew2,L3aNCsigma_xynew1,L3aNCsigma_xxnew3,L3aNCsigma_yynew3,L3aNCsigma_xynew2,L3aNCsigma_xynew3]=ForceElastic(L3j1upNormal,L3j1downNormal,L3j2upShear,L3j2downShear,nx,NCsigma_xx,NCsigma_yy,NCsigma_xy,L3Coeff_32,L3Coeff_34,L3Coeff_36,L3Coeff_38,L3Coeff_39,L3Coeff_310,NCv11,NCv12,FourthOrder,tt);
         
      otherwise
          
         [ NCsigma_xx,NCsigma_yy,NCsigma_xy,L3aNCsigma_xxnew1,L3aNCsigma_xxnew2,L3aNCsigma_yynew1,L3aNCsigma_yynew2,L3aNCsigma_xynew1,L3aNCsigma_xxnew3,L3aNCsigma_yynew3,L3aNCsigma_xynew2,L3aNCsigma_xynew3]=ForceElastic(L3j1upNormal,L3j1downNormal,L3j2upShear,L3j2downShear,nx,NCsigma_xx,NCsigma_yy,NCsigma_xy,L3Coeff_32,L3Coeff_34,L3Coeff_36,L3Coeff_38,L3Coeff_39,L3Coeff_310,NCv11,NCv12,FourthOrder,tt,L3aNCsigma_xxnew1,L3aNCsigma_xxnew2,L3aNCsigma_yynew1,L3aNCsigma_yynew2,L3aNCsigma_xynew1,L3aNCsigma_xxnew3,L3aNCsigma_yynew3,L3aNCsigma_xynew2,L3aNCsigma_xynew3);

          
            end
  
end 

%%

 [ NCsigma_xx,NCsigma_yy,NCsigma_xy,NCp]=AbsorbingBoundary02(NCsigma_xx,NCsigma_yy,NCsigma_xy,NCp,boundary,BABS,nx,ny);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ==================== Part 6: MainPart_Displacements  ====================      

%--------------------------------------------------------------------

switch(EffectiveStress)
    
    case 1   
        
  NCeff_sigma_xx = NCsigma_xx + L2alpha * NCp ;

  NCeff_sigma_yy = NCsigma_yy + L2alpha * NCp;
  
end
%--------------------------------------------------------------------

  NCu11=NCu11+NCv11*dt;                 
 
  NCu12=NCu12+NCv12*dt;   
  
  NCu21=NCu21+NCv21*dt;            

  NCu22=NCu22+NCv22*dt;     
  
%--------------------------------------------------------------------- 

      if tt/INTERVAL==fix(tt/INTERVAL)
             
       sigma_xx=NCsigma_xx(:,c);
       sigma_yy=NCsigma_yy(:,c);
       effsigma_xx=NCeff_sigma_xx(:,c);
       effsigma_yy=NCeff_sigma_yy(:,c);
        
       p=NCp(:,c);
       u11=NCu11(:,c);
       u12=NCu12(:,c);
       u21=NCu21(:,c);
       u22=NCu22(:,c);
       
      file=[num2str(tt/INTERVAL),'-Noncrack.mat'];
     
       save(file,'sigma_xx','sigma_yy','u11','u12','p','u21','u22','effsigma_xx','effsigma_yy')
%       save(file)
      end      
end

timeElapsed = toc




